--!strict
-- generationId: fea86c53-22c5-4a71-80e9-5a0b66d93cde
local CSG = require(script.Dependencies.ConstructiveSolidGeometry)
local GP = require(script.Dependencies.GeometryPrimitives)
local SO = require(script.Dependencies.SmartObject)
local MU = require(script.Dependencies.MathUtils)


local Sofa = {}

type Parameters = {
	Size: Vector3,
	Attributes: {
		Color: Color3?,
		Material: string?,
	},
}
local startTime = 0
local timerThread : thread = task.spawn(function()
while true do
	if not script:IsDescendantOf(game) then
		startTime = 0
		return
	end
	if startTime > 0 then
		local elapsed = tick() - startTime
		print("[ProceduralModel] " .. script:GetFullName() .. " rendering... " .. string.format("%.0f", elapsed) .. " seconds")
	end
	task.wait(3)
end
end)
script.Destroying:Connect(function()
	task.cancel(timerThread)
end)

Sofa.OnGenerate = function(parameters: Parameters, targetContainer: Instance)
	-- Timer setup
	startTime = tick()

	local sofa = GP.model("Sofa", nil)-- Fix orientation of the model
	sofa.WorldPivot = CFrame.identity
	
	
	local smartWidth = parameters.Size.X
	local smartHeight = parameters.Size.Y
	local smartDepth = parameters.Size.Z
	
	local scaleY = smartHeight / 10
	local scaleZ = smartDepth / 10
	
	local rustColor = parameters.Attributes.Color or Color3.fromRGB(195, 85, 55)
	local fabricMat = parameters.Attributes.Material or "Fabric"
	
	-- Metrics
	local armWidth = 0.9
	local innerWidth = math.max(2.0, smartWidth - (armWidth * 2))
	local halfW = smartWidth / 2
	
	local depth = 3.8 * scaleZ
	local halfD = depth / 2
	local backThickness = 0.7 * scaleZ
	local seatDepth = depth - backThickness - 0.2 * scaleZ
	
	local totalHeight = 3.4 * scaleY
	local skirtHeight = 0.8 * scaleY
	local seatBaseHeight = 0.4 * scaleY
	local seatTopY = skirtHeight + seatBaseHeight
	local seatCushionThickness = 0.65 * scaleY
	
	local armHeight = 2.1 * scaleY
	local armRollRadius = armWidth * 0.55
	
	local backCushionHeight = totalHeight - seatTopY - 0.1 * scaleY
	local backCushionThickness = 0.7 * scaleZ
	
	local idealCushionWidth = 2.5
	local seatCount = math.max(1, math.floor(innerWidth / idealCushionWidth + 0.5))
	local cushionWidth = innerWidth / seatCount
	local cushionGap = 0.03
	
	-- Top-level models requested by user
	local seat = GP.model("seat", sofa)
	local backrest = GP.model("backrest", sofa)
	local armrests = GP.model("armrests", sofa)
	
	-- ==========================================
	-- ARMRESTS
	-- ==========================================
	-- Left Arm (+X)
	local leftArmX = halfW - armWidth/2
	GP.roundedBox("LeftArmBody", 
	    Vector3.new(leftArmX, armHeight/2, 0),
	    Vector3.new(armWidth, armHeight, depth),
	    0.1, rustColor, fabricMat, armrests)
	
	GP.cylinder("LeftArmRoll",
	    Vector3.new(leftArmX, armHeight, -halfD),
	    Vector3.new(leftArmX, armHeight, halfD),
	    armRollRadius, rustColor, fabricMat, armrests)
	
	-- Right Arm (-X)
	local rightArmX = -halfW + armWidth/2
	GP.roundedBox("RightArmBody", 
	    Vector3.new(rightArmX, armHeight/2, 0),
	    Vector3.new(armWidth, armHeight, depth),
	    0.1, rustColor, fabricMat, armrests)
	
	GP.cylinder("RightArmRoll",
	    Vector3.new(rightArmX, armHeight, -halfD),
	    Vector3.new(rightArmX, armHeight, halfD),
	    armRollRadius, rustColor, fabricMat, armrests)
	
	
	-- ==========================================
	-- BACKREST
	-- ==========================================
	local backZ = halfD - backThickness/2
	GP.roundedBox("BackFrame",
	    Vector3.new(0, (armHeight + skirtHeight)/2, backZ),
	    Vector3.new(innerWidth, armHeight - skirtHeight, backThickness),
	    0.1, rustColor, fabricMat, backrest)
	
	-- Back Cushions
	local backCushionCenterY = seatTopY + backCushionHeight/2
	local backCushionCenterZ = halfD - backThickness - backCushionThickness/2 + 0.1
	
	for i = 1, seatCount do
	    local xPos = (innerWidth / 2) - (cushionWidth / 2) - ((i - 1) * cushionWidth)
	    
	    GP.roundedBox("BackCushion_" .. i,
	        Vector3.new(xPos, backCushionCenterY, backCushionCenterZ),
	        Vector3.new(cushionWidth - cushionGap, backCushionHeight, backCushionThickness),
	        0.15 * scaleY, rustColor, fabricMat, backrest)
	end
	
	-- ==========================================
	-- SEAT (Base, Skirt, Cushions)
	-- ==========================================
	-- Seat Base Frame (hidden under cushions)
	GP.roundedBox("SeatBaseFrame",
	    Vector3.new(0, skirtHeight + seatBaseHeight/2, (halfD - backThickness - halfD)/2),
	    Vector3.new(innerWidth, seatBaseHeight, depth - backThickness),
	    0.05, rustColor, fabricMat, seat)
	
	-- Front Skirt Center
	local skirtThickness = 0.1 * scaleZ
	GP.axisAlignedBlockFromCorners("SkirtFrontCenter",
	    Vector3.new(innerWidth/2 - 0.05, 0.05, -halfD + 0.05),
	    Vector3.new(-innerWidth/2 + 0.05, skirtHeight, -halfD + 0.05 + skirtThickness),
	    rustColor, fabricMat, seat)
	
	-- Front Skirt Left (+X)
	GP.axisAlignedBlockFromCorners("SkirtFrontLeft",
	    Vector3.new(halfW - 0.05, 0.05, -halfD + 0.05),
	    Vector3.new(innerWidth/2 + 0.05, skirtHeight, -halfD + 0.05 + skirtThickness),
	    rustColor, fabricMat, seat)
	
	-- Front Skirt Right (-X)
	GP.axisAlignedBlockFromCorners("SkirtFrontRight",
	    Vector3.new(-innerWidth/2 - 0.05, 0.05, -halfD + 0.05),
	    Vector3.new(-halfW + 0.05, skirtHeight, -halfD + 0.05 + skirtThickness),
	    rustColor, fabricMat, seat)
	
	-- Side Skirt Left (+X)
	GP.axisAlignedBlockFromCorners("SkirtSideLeft",
	    Vector3.new(halfW - 0.05 - skirtThickness, 0.05, -halfD + 0.15),
	    Vector3.new(halfW - 0.05, skirtHeight, halfD - 0.05),
	    rustColor, fabricMat, seat)
	
	-- Side Skirt Right (-X)
	GP.axisAlignedBlockFromCorners("SkirtSideRight",
	    Vector3.new(-halfW + 0.05, 0.05, -halfD + 0.15),
	    Vector3.new(-halfW + 0.05 + skirtThickness, skirtHeight, halfD - 0.05),
	    rustColor, fabricMat, seat)
	
	-- Seat Cushions
	local seatCushionCenterY = seatTopY + seatCushionThickness/2
	local seatCushionCenterZ = -halfD + seatDepth/2 - 0.05
	
	for i = 1, seatCount do
	    local xPos = (innerWidth / 2) - (cushionWidth / 2) - ((i - 1) * cushionWidth)
	    
	    GP.roundedBox("SeatCushion_" .. i,
	        Vector3.new(xPos, seatCushionCenterY, seatCushionCenterZ),
	        Vector3.new(cushionWidth - cushionGap, seatCushionThickness, seatDepth),
	        0.15 * scaleY, rustColor, fabricMat, seat)
	end
	
	sofa.Parent = targetContainer
	-- reposition
	for _, part in targetContainer:GetDescendants() do
		if part:IsA("BasePart") then
			part.CFrame -= Vector3.yAxis * parameters.Size.Y / 2
		end
	end
	for _, model in targetContainer:GetDescendants() do
		if model:IsA("Model") then
			model.WorldPivot -= Vector3.yAxis * parameters.Size.Y / 2
		end
	end

	-- Stop timer when generation completes
	local timeElapsed = tick() - startTime
	startTime = 0
	if timeElapsed > 3 and script:IsDescendantOf(game) then
		print("[ProceduralModel] " .. script:GetFullName() .. " rendering completed")
	end

end

return Sofa

